# Juror Research Tool — UI Flows

## Overview

This document describes the user interface flows for the juror research module. These are functional specifications—visual design is determined by the parent application's design system.

---

## Screen Map

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           SCREEN MAP                                    │
│                                                                         │
│  ┌─────────────────┐                                                   │
│  │  Juror List     │ ◄─── Entry point for case                         │
│  │  (per case)     │                                                   │
│  └────────┬────────┘                                                   │
│           │                                                             │
│     ┌─────┴─────┬──────────────┬──────────────┐                        │
│     ▼           ▼              ▼              ▼                        │
│  ┌──────┐  ┌─────────┐  ┌───────────┐  ┌──────────────┐               │
│  │Single│  │ Batch   │  │ Document  │  │ Juror Detail │               │
│  │Lookup│  │ Import  │  │ Capture   │  │ + Profile    │               │
│  └──────┘  └─────────┘  └─────┬─────┘  └──────────────┘               │
│                               │                                        │
│                               ▼                                        │
│                         ┌───────────┐                                  │
│                         │ OCR Review│                                  │
│                         │ & Confirm │                                  │
│                         └───────────┘                                  │
│                                                                         │
│  Overlays / Modals:                                                    │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐        │
│  │ Candidate       │  │ Export          │  │ Venue           │        │
│  │ Selection       │  │ Options         │  │ Settings        │        │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 1. Juror List (Main View)

The primary interface for managing jurors within a case.

### Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ◄ Back to Case                                          [Export ▼]    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Jury Research — Smith v. Acme Corp                                    │
│                                                                         │
│  👥 3 team members active: Sarah (you), Mike, Priya                    │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ [🔍 Search jurors...]           [+ Add Juror] [📷 Capture] [⬆ Import] │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Filters: [All ▼] [Status ▼] [Flagged ▼]          47 jurors    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ # │ Name           │ Age │ City      │ Status      │ Flags     │   │
│  │───┼────────────────┼─────┼───────────┼─────────────┼───────────│   │
│  │ 1 │ Maria Garcia   │ 42  │ Houston   │ ✓ Matched   │ 🚩 Concern │   │
│  │ 2 │ John Smith     │ 35  │ Austin    │ 3 candidates│           │   │
│  │ 3 │ Sarah Johnson  │ 58  │ Houston   │ ⟳ Searching │           │   │
│  │ 4 │ David Lee      │ 29  │ Katy      │ ✓ Matched   │ ⭐ Keep   │   │
│  │ 5 │ ...            │     │           │             │           │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  [Load more...]                                                        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Interactions

| Element | Action | Result |
|---------|--------|--------|
| Row click | Navigate | Opens Juror Detail |
| Status "N candidates" | Click | Opens Candidate Selection overlay |
| + Add Juror | Click | Opens Single Lookup panel |
| 📷 Capture | Click | Opens Document Capture flow |
| ⬆ Import | Click | Opens Batch Import modal |
| Export | Click | Opens Export Options |
| Flag icon | Hover | Shows flag reason tooltip |
| Team members | Hover | Shows what each person is viewing |

### Real-Time Updates

- New jurors appear at top of list with subtle highlight
- Status changes animate (e.g., "Searching" → "3 candidates")
- Flags appear instantly when teammates add them
- "Mike is viewing" indicator appears on row if teammate has it open

---

## 2. Single Lookup (Quick Add)

Inline panel for rapid juror entry during voir dire.

### Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Quick Lookup                                               [✕ Close]  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Name *        [Maria Garcia________________]                   │   │
│  │                                                                 │   │
│  │  Age           [42__]    City         [Houston_________]       │   │
│  │                                                                 │   │
│  │  Occupation    [Teacher________________]                       │   │
│  │                                                                 │   │
│  │  ▼ More fields (address, employer, email, phone)               │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  Venue: [Harris County, TX ▼]                                          │
│                                                                         │
│                                          [Cancel]  [Search & Add]      │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Behavior

1. User types name (required), optionally adds details
2. "Search & Add" creates Juror record AND triggers search
3. Panel closes, new juror appears in list with "Searching" status
4. Results populate via WebSocket (no page refresh needed)

### Keyboard Shortcuts

- `Enter` in any field → Submit (Search & Add)
- `Tab` → Move between fields
- `Escape` → Close panel

---

## 3. Document Capture Flow

For photographing juror questionnaires or jury lists.

### Step 1: Capture

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Document Capture                                          [✕ Cancel]  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Document type:                                                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                    │
│  │ 📋 Jury     │  │ 📄 Single   │  │ 📝 Notes    │                    │
│  │    List     │  │ Questionnaire│  │             │                    │
│  │  (multiple) │  │  (one juror) │  │ (handwritten)│                   │
│  └─────────────┘  └─────────────┘  └─────────────┘                    │
│       ▲ selected                                                       │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                 │   │
│  │                    📷 Camera Preview                            │   │
│  │                                                                 │   │
│  │                    [Align document edges]                       │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  Pages captured: 2                                                     │
│  ┌────┐  ┌────┐  ┌────────┐                                           │
│  │ p1 │  │ p2 │  │ + Add  │                                           │
│  │    │  │    │  │  page  │                                           │
│  └────┘  └────┘  └────────┘                                           │
│                                                                         │
│                                          [Retake Last]  [Process →]   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Step 2: Processing (Automatic)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Processing Document...                                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│                         ⟳ Analyzing pages...                           │
│                                                                         │
│                    [████████████░░░░░░░░] 60%                          │
│                                                                         │
│                    Extracting juror information                        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Step 3: Review & Confirm

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Review Extracted Jurors                                   [✕ Cancel]  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Found 12 jurors. Review and correct any errors.                       │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ ☑ │ Name            │ Age │ City       │ Occupation    │ ⚠️   │   │
│  │───┼─────────────────┼─────┼────────────┼───────────────┼──────│   │
│  │ ☑ │ Maria Garcia    │ 42  │ Houston    │ Teacher       │      │   │
│  │ ☑ │ John Smith      │ 35  │ Austin     │ Engineer      │      │   │
│  │ ☑ │ [Sarah Joh...]  │ [58]│ [Houston]  │ [Retired]     │ ⚠️   │   │
│  │ ☐ │ illegible       │     │            │               │ ⚠️   │   │
│  │ ☑ │ David Lee       │ 29  │ Katy       │ Sales         │      │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ⚠️ = Low confidence, please verify                                    │
│  Click any cell to edit                                                │
│                                                                         │
│  Venue: [Harris County, TX ▼]                                          │
│                                                                         │
│  ☑ Start searches immediately after adding                             │
│                                                                         │
│                              [Cancel]  [Add 11 Selected Jurors]        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Interactions

| Element | Action | Result |
|---------|--------|--------|
| Cell click | Edit | Inline edit mode |
| ⚠️ row | Focus | Highlights for review |
| Checkbox | Toggle | Include/exclude from import |
| Thumbnail | Click | Shows source image for that row |

---

## 4. Batch Import

For CSV/spreadsheet upload.

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Import Juror List                                         [✕ Close]   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                 │   │
│  │            Drag & drop CSV or Excel file here                  │   │
│  │                                                                 │   │
│  │                    or [Browse files...]                        │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  Expected columns: Name (required), Age, City, Occupation, Address     │
│                                                                         │
│  [Download template]                                                   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

After file upload, shows same Review & Confirm screen as Document Capture.

---

## 5. Juror Detail View

Comprehensive view of a single juror and their research results.

### Layout (Before Match Confirmed)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ◄ Back to Juror List                                                  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Maria Garcia                                                          │
│  42 years old • Houston • Teacher                                      │
│  Added by Sarah • 10 minutes ago • via OCR capture                     │
│                                                                         │
│  ───────────────────────────────────────────────────────────────────── │
│                                                                         │
│  POTENTIAL MATCHES (3)                               [🔄 Re-search]    │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  ┌─────┐                                                        │   │
│  │  │ 👤  │  Maria L Garcia                           87% match   │   │
│  │  │photo│  42 • Houston, TX • Houston ISD                       │   │
│  │  └─────┘  Sources: Voter, FEC, LinkedIn                        │   │
│  │           FEC: $500 to Democratic candidates (2020-2024)       │   │
│  │                                                [Select Match]   │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │  ┌─────┐                                                        │   │
│  │  │ 👤  │  Maria Garcia-Rodriguez                   64% match   │   │
│  │  │photo│  44 • Houston, TX • Self-employed                     │   │
│  │  └─────┘  Sources: Voter, Whitepages                           │   │
│  │                                                [Select Match]   │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │  ┌─────┐                                                        │   │
│  │  │ 👤  │  Maria A Garcia                           52% match   │   │
│  │  │photo│  39 • Katy, TX • Retail                               │   │
│  │  └─────┘  Sources: Voter                                       │   │
│  │                                                [Select Match]   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  [None of these are correct]                                           │
│                                                                         │
│  ───────────────────────────────────────────────────────────────────── │
│                                                                         │
│  TEAM NOTES                                                [+ Add]     │
│  (none yet)                                                            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Layout (After Match Confirmed)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ◄ Back to Juror List                                    [Export PDF]  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Maria L Garcia                                        ✓ Confirmed     │
│  42 years old • Houston, TX • Teacher at Houston ISD                   │
│  Matched by Mike • 5 minutes ago                       [Change match]  │
│                                                                         │
│  ───────────────────────────────────────────────────────────────────── │
│                                                                         │
│  ┌──────────────────────────────────┐  ┌─────────────────────────────┐ │
│  │ POLITICAL                        │  │ SOCIAL                      │ │
│  │                                  │  │                             │ │
│  │ Voter Registration               │  │ LinkedIn                    │ │
│  │ • Democratic Party               │  │ linkedin.com/in/mgarcia... │ │
│  │ • Registered: 2008               │  │ "Teacher passionate about..."│ │
│  │ • Voted: 2020, 2022, 2024        │  │                             │ │
│  │                                  │  │ Facebook                    │ │
│  │ FEC Donations                    │  │ (Profile found, limited)   │ │
│  │ • $250 to Beto O'Rourke (2022)  │  │                             │ │
│  │ • $250 to Biden Victory (2020)  │  │ Twitter: Not found          │ │
│  │                                  │  │                             │ │
│  └──────────────────────────────────┘  └─────────────────────────────┘ │
│                                                                         │
│  ┌──────────────────────────────────┐  ┌─────────────────────────────┐ │
│  │ LEGAL                            │  │ NEWS                        │ │
│  │                                  │  │                             │ │
│  │ Court Cases: None found          │  │ No direct mentions found   │ │
│  │                                  │  │                             │ │
│  │ [Search PACER] [Search TX Courts]│  │ [Search more news sources] │ │
│  │                                  │  │                             │ │
│  └──────────────────────────────────┘  └─────────────────────────────┘ │
│                                                                         │
│  ───────────────────────────────────────────────────────────────────── │
│                                                                         │
│  TEAM NOTES                                                [+ Add]     │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 🚩 Sarah (2 min ago):                                           │   │
│  │ "Strong Democratic donor - may be sympathetic to plaintiff.     │   │
│  │  Recommend further questioning about corporate bias."           │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  FLAG: [⭐ Keep] [🚩 Concern] [❌ Strike] [Clear flag]                  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Interactions

| Element | Action | Result |
|---------|--------|--------|
| Select Match | Click | Confirms candidate, loads full profile |
| Change match | Click | Returns to candidate selection |
| Social links | Click | Opens in new tab |
| Search PACER | Click | Triggers court record search (may take time) |
| Add note | Click | Opens note editor |
| Flag buttons | Click | Sets/clears juror flag |

---

## 6. Offline Mode

When connectivity is lost, the UI adapts gracefully.

### Offline Banner

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ⚠️ You're offline. Captures will be queued and processed when         │
│     connection is restored.                              [Dismiss]     │
└─────────────────────────────────────────────────────────────────────────┘
```

### Offline Juror List

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Jury Research — Smith v. Acme Corp                      📴 OFFLINE    │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ # │ Name           │ Age │ City      │ Status           │       │   │
│  │───┼────────────────┼─────┼───────────┼──────────────────┼───────│   │
│  │ 1 │ Maria Garcia   │ 42  │ Houston   │ ✓ Matched        │       │   │
│  │ 2 │ John Smith     │ 35  │ Austin    │ 📤 Queued        │       │   │
│  │ 3 │ NEW: captured  │ --  │ --        │ 📤 Queued        │       │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  📤 3 items queued for sync                                            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Sync Progress (When Reconnected)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  🔄 Syncing... 2 of 3 items uploaded                     [████████░░]  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Export Options

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Export Juror Research                                     [✕ Close]   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Format:                                                               │
│  ○ PDF Report (recommended for sharing)                                │
│  ○ Excel Spreadsheet                                                   │
│  ○ CSV                                                                 │
│                                                                         │
│  Include:                                                              │
│  ☑ Juror summary (name, age, city, occupation)                        │
│  ☑ Matched profile details                                            │
│  ☑ Political information (voter, donations)                           │
│  ☑ Social media profiles                                              │
│  ☑ Court records                                                      │
│  ☑ Team notes                                                         │
│  ☐ Unmatched candidates                                               │
│                                                                         │
│  Jurors:                                                               │
│  ○ All jurors (47)                                                    │
│  ○ Flagged only (8)                                                   │
│  ○ Selected jurors: [Select...]                                       │
│                                                                         │
│                                          [Cancel]  [Generate Export]   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Presence & Collaboration Indicators

### Header Presence Bar

Shows who's active on the case:

```
👥 3 active: Sarah (you), Mike viewing #4, Priya capturing
```

Hover expands to show details.

### Row-Level Indicators

When a teammate is viewing a specific juror:

```
│ 4 │ David Lee      │ 29  │ Katy      │ ✓ Matched   │ 👁 Mike │
```

### Real-Time Toast Notifications

Brief, non-blocking notifications:

```
┌─────────────────────────────────────┐
│ 📸 Priya captured 8 new jurors     │
└─────────────────────────────────────┘
```

```
┌─────────────────────────────────────┐
│ 🚩 Mike flagged Juror #12 as       │
│    "Concern"                        │
└─────────────────────────────────────┘
```

---

## Mobile Considerations

The interface should work on tablets (primary mobile use case in courtroom).

### Key Adaptations

1. **Touch-friendly targets**: All buttons/rows minimum 44px height
2. **Camera integration**: Native camera API for document capture
3. **Simplified list view**: Collapse some columns, expand on tap
4. **Swipe actions**: Swipe row to flag or add note
5. **Bottom sheet modals**: Instead of centered modals on small screens

### Portrait vs Landscape

- **Portrait**: Single-column layout, stacked sections
- **Landscape**: Two-column layout similar to desktop (preferred for tablets)
